package jp.co.jri.nksol.model;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * 出力レコードオブジェクトのテストです。
 */
public class OutputFileRecObjectTest {

    /**
     * コンストラクターで設定した各項目をgetterから取得できることを確認します。
     */
    @Test
    void testGetRicCode() {
        var t = new OutputFileRecObject("5677.T", "col1-1", "col2-1");
        assertEquals("5677.T", t.getRicCode());
        assertEquals("col1-1", t.getCol1());
        assertEquals("col2-1", t.getCol2());
    }

}
