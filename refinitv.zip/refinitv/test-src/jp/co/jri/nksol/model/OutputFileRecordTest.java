package jp.co.jri.nksol.model;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * ファイルレコードのテストです。
 */
public class OutputFileRecordTest {

    /**
     * 生成したレコードからRICコードと各項目の値を取得できることを確認します。
     */
    @Test
    void testGetRicCode() {
        var t = new InputFileRecord("5677.T", "col1", "col2");

        assertEquals(t.ricCode(), "5677.T");
        assertEquals(t.col1(), "col1");
        assertEquals(t.col2(), "col2");
    }

}
