
# extensinos 

## $ code --list-extensions --profile="Java General"
- mechatroner.rainbow-csv
- ms-ceintl.vscode-language-pack-ja
- ms-vscode.live-server
- nickheap.vscode-ant
- pkief.material-icon-theme
- redhat.java
- redhat.vscode-xml
- seatonjiang.gitmoji-vscode
- sonarsource.sonarlint-vscode
- vscjava.vscode-java-debug
- vscjava.vscode-java-dependency
- vscjava.vscode-java-pack
- vscjava.vscode-java-test
- vscjava.vscode-maven