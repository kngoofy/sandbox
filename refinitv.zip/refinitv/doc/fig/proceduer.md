# a

```mermaid
flowchart LR
    A@{ shape: lin-doc, label: "InputFile" }
    B@{ shape: rect, label: "Get Jika Value" }
    C@{ shape: lin-doc, label: "OutputFile" }
A--> B
B--> C
```

├── packages/
│   ├── mermaid/

## b
```mermaid
treeView-beta
├── packages/
│   ├── mermaid/
│   │   ├── src/
│   │   │   ├── parser.ts
│   │   │   └── renderer.ts
│   │   └── package.json
│   ├── commons-codec-1.23.0.jar
│   ├── commons-codec-1.23.0.jar
│   ├── commons-codec-1.23.0.jar
│   └── parser/
│       └── src/
└── README.md
```
