# Java Library

## CSV用途

| #   | ライブラリ名  | 使用しているjar          | 説明 |
| :-- | :------------ | :----------------------- | ---- |
| 1   | commons-codec | commons-codec-1.23.0.jar |      |
| 2   | commons-csv   | commons-csv-1.14.1.jar   |      |
| 3   | commons-io    | commons-io-2.22.0.jar    |      |

## log用途

| #   | ライブラリ名    | 使用しているjar           | 説明 |
| :-- | :-------------- | :------------------------ | ---- |
| 1   | logback-classic | logback-classic-1.6.8.jar |      |
| 2   | logback-core    | logback-core-1.6.8.jar    |      |
| 3   | slf4j-api       | slf4j-api-2.0.20.jar      |      |

## JUnit用途

| #   | ライブラリ名                      | 使用しているjar                             | 説明 |
| :-- | :-------------------------------- | :------------------------------------------ | ---- |
| 3   | junit-platform-console-standalone | junit-platform-console-standalone-6.1.3.jar |      |