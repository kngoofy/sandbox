package jp.co.jri.nksol.util;

import java.io.IOException;
import java.nio.file.Path;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.jri.nksol.exception.ConfigException;
import jp.co.jri.nksol.model.Prop;

/**
 * app.propertiesからアプリケーション設定を読み込み、
 * {@link Prop}オブジェクトへ設定するユーティリティクラス。
 */
public class LoadProperty {

    private static final Logger logger = LoggerFactory.getLogger(LoadProperty.class);

    private LoadProperty() {
        // ユーティリティクラスのため、インスタンス化を禁止します。
        throw new IllegalStateException("Utility class");
    }

    /**
     * 指定されたPropオブジェクトにアプリケーション設定を読み込んで格納します。
     *
     * @param prop 設定値を格納するPropオブジェクト
     * @return 設定を読み込んで格納できた場合は {@code true}
     * @throws IOException プロパティファイルの読み込みで入出力エラーが発生した場合
     * @throws ConfigException 必須のシステムプロパティまたは設定項目が不足している場合
     */
    // public static boolean loadProperty(String propFile, Prop prop) throws
    // IOException {
    public static boolean loadProperty(Prop prop) throws IOException, ConfigException {

        // システムプロパティ prop.file に アプリケーションプロパティ名がセットされており、ファイル名を取得
        // ※アプリケーションプロパティファイル名が取得できない場合は、プログラムを終了させます。
        String propFile = SystemPropertyUtil.getRequiredProperty("prop.file");
        logger.info("システムプロパティの -Dprop.file にアプリケーションプロパティファイル{}が指定されています。", propFile);

        // アプリケーションプロパティからの各プロパティを組み立てる。
        // ※アプリケーションプロパティの必須プロパティが取得できない場合は、プログラムを終了させます。
        Properties properties = new Properties();
        logger.info("アプリケーションプロパティファイル {} の中の各プロパティを読み取り、組み立てます。", propFile);
        ApplicationProperyUtli.loadApplicationPropery(propFile, properties);

        // try (InputStream input = Files.newInputStream(Path.of(propFile))) {
        // properties.load(input);
        // } catch (IOException e) {
        // logger.error("Failed to load properties from file: {}", propFile, e);
        // throw new ConfigException("Failed to load properties from file: " + propFile,
        // e);
        // }

        // プロパティの値を取得
        String appName = properties.getProperty("app.name");
        String appVersion = properties.getProperty("app.version");
        Path inputPath = Path.of(properties.getProperty("input.file.path"));
        Path outputPath = Path.of(properties.getProperty("output.file.path"));
        String serverUrl = properties.getProperty("server.url");

        logger.info("Property appName: {}", appName);
        logger.info("Property appVersion: {}", appVersion);
        logger.info("Property inputPath: {}", inputPath);
        logger.info("Property outputPath: {}", outputPath);
        logger.info("Property serverUrl: {}", serverUrl);

        // if (inputPath == null || outputPath == null || serverUrl == null) {
        // System.out.println("プロパティファイルの読み込みで問題があるようです。NULL値あり");
        // logger.error("プロパティファイルの読み込みで問題があるようです。NULL値あり");
        // return false;
        // }

        // プロパティをPropオブジェクトに設定
        prop.setAppName(appName);
        prop.setAppVersion(appVersion);
        prop.setInputFilePath(inputPath);
        prop.setOutputFilePath(outputPath);
        prop.setServerUrl(serverUrl);

        // すべてのプロパティが正常に読み込まれた場合はtrueを返す
        return true;
    }
}
