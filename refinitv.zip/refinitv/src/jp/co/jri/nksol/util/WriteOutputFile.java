package jp.co.jri.nksol.util;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.jri.nksol.model.OutputFileRecObject;
import jp.co.jri.nksol.model.OutputFileRecord;

/**
 * 出力レコードのリストをCSVファイルへ書き込むユーティリティクラス。
 */
public class WriteOutputFile {

    private static final Logger logger = LoggerFactory.getLogger(WriteOutputFile.class);

    private WriteOutputFile() {
        // ユーティリティクラスのため、インスタンス化を禁止します。
        throw new IllegalStateException("Utility class");
    }

    public static boolean writeOutputFileRecord(Path outputFilePath, List<OutputFileRecord> listRec)
            throws IOException {

        // CSVFormatの設定
        CSVFormat format = CSVFormat.DEFAULT.builder()
                .setHeader("ricCode", "col11", "col2")
                .get();

        //
        logger.info("Write CSV File ...");

        // CSVファイルに書き込む
        try (CSVPrinter printer = new CSVPrinter(
                Files.newBufferedWriter(outputFilePath, StandardCharsets.UTF_8), format)) {
            for (OutputFileRecord rec : listRec) {
                printer.printRecord(
                        rec.ricCode(),
                        rec.col1(),
                        rec.col2());

                //
                logger.info("OutputRec={}", rec);

            }
        } catch (IOException e) {
            logger.error("アウトプットファイルの書き込みに失敗しました。: {}", outputFilePath, e);
            // throw new IOException("Failed to write output file: " + outputFilePath, e);

            // プログラムを終了する
            logger.error("プログラムを終了させます。");
            System.exit(1);
        }

        // すべてのレコードが正常に書き込まれた場合はtrueを返す
        return true;
    }

    /**
     * 出力CSVを生成し、各レコードのricCodeとstatusをヘッダー付きで書き込む。
     *
     * @param outputFilePath 出力CSVファイルのパス
     * @param listRec        出力するレコードのリスト
     * @return すべてのレコードを書き込めた場合はtrue
     * @throws IOException ファイルの書き込みに失敗した場合
     */
    public static boolean writeOutputFile(Path outputFilePath, List<OutputFileRecObject> listRec)
            throws IOException {

        // CSVFormatの設定
        CSVFormat format = CSVFormat.DEFAULT.builder()
                .setHeader("ricCode", "status")
                .get();

        //
        logger.info("Write CSV File ...");

        // CSVファイルに書き込む
        try (CSVPrinter printer = new CSVPrinter(
                Files.newBufferedWriter(outputFilePath, StandardCharsets.UTF_8), format)) {
            for (OutputFileRecObject rec : listRec) {
                printer.printRecord(
                        rec.getRicCode(),
                        rec.getCol1(),
                        rec.getCol2());

                //
                logger.info("OutputRec={}", rec);

            }
        } catch (IOException e) {
            logger.error("アウトプットファイルの書き込みに失敗しました。: {}", outputFilePath, e);
            // throw new IOException("Failed to write output file: " + outputFilePath, e);

            // プログラムを終了する
            logger.error("プログラムを終了させます。");
            System.exit(1);
        }

        // すべてのレコードが正常に書き込まれた場合はtrueを返す
        return true;
    }

}
