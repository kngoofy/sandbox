package jp.co.jri.nksol.util;

import java.io.IOException;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.jri.nksol.model.InputFileRecObject;
import jp.co.jri.nksol.model.InputFileRecord;

/**
 * 入力CSVファイルを読み込み、レコードをオブジェクトのリストとして返すユーティリティクラス。
 */
public class ReadInputFile {

    private static final Logger logger = LoggerFactory.getLogger(ReadInputFile.class);

    private ReadInputFile() {
        // ユーティリティクラスのため、インスタンス化を禁止します。
        throw new IllegalStateException("Utility class");
    }

    /**
     * CSVファイルを読み込み、各行を入力レコードに変換します。
     * ヘッダーの {@code ricCode}、{@code col1}、{@code col2} 列から値を取得します。
     *
     * @param inputFilePath 読み込むCSVファイルのパス
     * @return CSVの各行から生成した入力レコードのリスト
     * @throws IOException CSVファイルの読み込みまたは解析に失敗した場合
     */
    public static List<InputFileRecord> readInputFileRecord(Path inputFilePath) throws IOException {

        List<InputFileRecord> listRec = new ArrayList<>();

        // 先頭行をヘッダーとして扱い、データ行から項目名で値を取得します。
        CSVFormat format = CSVFormat.DEFAULT.builder()
                .setHeader()
                .setSkipHeaderRecord(true)
                .get();

        logger.info("Read CSV File ...");

        // CSVファイルを読み込む
        try (Reader reader = Files.newBufferedReader(inputFilePath, StandardCharsets.UTF_8);
                CSVParser parser = format.parse(reader)) {

            for (CSVRecord csvRecord : parser) {

                InputFileRecord rec = new InputFileRecord(
                        csvRecord.get("ricCode"),
                        csvRecord.get("col1"),
                        csvRecord.get("col2"));

                logger.info("inputRec={}", rec);

                listRec.add(rec);

            }

        } catch (IOException e) {
            logger.error("インプットファイルの読み込みに失敗しました。: {}", inputFilePath, e);
            // throw new IOException("Failed to read input file: " + inputFilePath, e);

            // 読み込みを継続できないため、エラーを記録してプログラムを終了します。
            logger.error("プログラムを終了させます。");
            System.exit(1);
        }

        // 読み込んだレコードのリストを返す
        return listRec;

    }

    /**
     * CSVファイルを読み込み、各行を入力レコードオブジェクトに変換します。
     * ヘッダーの {@code ricCode}、{@code col1}、{@code col2} 列から値を取得します。
     *
     * @param inputFilePath 入力CSVファイルのパス
     * @return CSVの各行から生成した入力レコードオブジェクトのリスト
     * @throws IOException ファイルの読み込みまたは解析に失敗した場合
     */
    public static List<InputFileRecObject> readInputFile(Path inputFilePath) throws IOException {

        List<InputFileRecObject> listRec = new ArrayList<>();

        // 先頭行をヘッダーとして扱い、データ行から項目名で値を取得します。
        CSVFormat format = CSVFormat.DEFAULT.builder()
                .setHeader()
                .setSkipHeaderRecord(true)
                .get();

        logger.info("Read CSV File ...");

        // CSVファイルを読み込む
        try (Reader reader = Files.newBufferedReader(inputFilePath, StandardCharsets.UTF_8);
                CSVParser parser = format.parse(reader)) {

            for (CSVRecord csvRecord : parser) {

                InputFileRecObject rec = new InputFileRecObject(
                        csvRecord.get("ricCode"),
                        csvRecord.get("col1"),
                        csvRecord.get("col2"));

                logger.info("inputRec={}", rec);

                listRec.add(rec);

            }

        } catch (IOException e) {
            logger.error("インプットファイルの読み込みに失敗しました。: {}", inputFilePath, e);
            // throw new IOException("Failed to read input file: " + inputFilePath, e);

            // 読み込みを継続できないため、エラーを記録してプログラムを終了します。
            logger.error("プログラムを終了させます。");
            System.exit(1);
        }

        // 読み込んだレコードのリストを返す
        return listRec;

    }
}
