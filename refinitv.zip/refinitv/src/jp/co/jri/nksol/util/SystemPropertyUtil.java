package jp.co.jri.nksol.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.jri.nksol.exception.ConfigException;

/**
 * システムプロパティを取得するユーティリティです。
 */
public class SystemPropertyUtil {

    private static final Logger logger = LoggerFactory.getLogger(SystemPropertyUtil.class);

    private SystemPropertyUtil() {
        // ユーティリティクラスのため、インスタンス化を禁止します。
        throw new IllegalStateException("Utility class");
    }

    /**
     * 指定されたキーの必須システムプロパティを取得します。
     * 値が未設定または空白の場合はエラーを記録してプログラムを終了します。
     *
     * @param key 取得するシステムプロパティのキー
     * @return キーに対応するシステムプロパティの値
     */
    public static String getRequiredProperty(String key) throws ConfigException {

        String result = null;
        try {
            String value = System.getProperty(key);
            if (value == null || value.isBlank()) {
                throw new ConfigException("必須システムプロパティが未指定です: [" + key + "]");
            }
            result = value;
        } catch (Exception e) {
            logger.error("システムプロパティの取得に失敗しました: key={} e={}", key, e);
            System.err.println("[CONFIG ERROR] " + e.getMessage());
            logger.error("java の起動引数に -Dprop.file=app.properties を指定してください。");

            // 設定値を取得できないため、エラーを記録してプログラムを終了します。
            logger.error("プログラムを終了させます。");
            System.exit(1);
        }

        logger.info("アプリケーションプロパティファイルの指定: key={} result={}", key, result);
        return result;
    }
}