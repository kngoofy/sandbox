package jp.co.jri.nksol.util;

import java.util.ArrayList;
import java.util.List;

import jp.co.jri.nksol.model.InputFileRecObject;
import jp.co.jri.nksol.model.InputFileRecord;
import jp.co.jri.nksol.model.OutputFileRecObject;
import jp.co.jri.nksol.model.OutputFileRecord;

/**
 * 入力レコードから出力レコードを組み立てるユーティリティです。
 */
public class BuildOutputFileRecord {

    private BuildOutputFileRecord() {
        // ユーティリティクラスのため、インスタンス化を禁止します。
        throw new IllegalStateException("Utility class");
    }

    /**
     * 入力レコードの各項目を引き継いで、出力レコードのリストを作成します。
     *
     * @param inputListRec 変換元の入力レコード一覧
     * @return 作成した出力レコード一覧
     */
    public static List<OutputFileRecord> buildOutputFileRecord(List<InputFileRecord> inputListRec) {

        List<OutputFileRecord> outputListRec = new ArrayList<>();

        for (var csvRecord : inputListRec) {

            OutputFileRecord rec = new OutputFileRecord(

                    csvRecord.ricCode(),
                    csvRecord.col1(),
                    csvRecord.col2()

            );
            outputListRec.add(rec);
        }

        return outputListRec;

    }

    /**
     * 入力レコードオブジェクトの各項目を引き継いで、出力レコードオブジェクトのリストを作成します。
     *
     * @param inputListObject 変換元の入力レコードオブジェクト一覧
     * @return 作成した出力レコードオブジェクト一覧
     */
    public static List<OutputFileRecObject> buildOutputFileObject(List<InputFileRecObject> inputListObject) {

        List<OutputFileRecObject> outputListRec = new ArrayList<>();

        for (var object : inputListObject) {

            OutputFileRecObject obj = new OutputFileRecObject(

                    object.getRicCode(),
                    object.getCol1(),
                    object.getCol2()

            );
            outputListRec.add(obj);
        }
        return outputListRec;

    }
}
