package jp.co.jri.nksol.util;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Optional;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.jri.nksol.exception.ConfigException;

/**
 * アプリケーション設定ファイルの読み込みと必須項目の確認を行うユーティリティです。
 */
public class ApplicationProperyUtli {

    private static final Logger logger = LoggerFactory.getLogger(ApplicationProperyUtli.class);

    private ApplicationProperyUtli() {
        // ユーティリティクラスのため、インスタンス化を禁止します。
        throw new IllegalStateException("Utility class");
    }

    /**
     * 指定されたプロパティファイルを読み込み、必須項目が設定されていることを確認します。
     * ファイルの読み込みに失敗した場合、または必須項目が不足している場合はログを出力して終了します。
     *
     * @param propFile 読み込むプロパティファイルのパス
     * @param properties 読み込んだ設定値を格納するオブジェクト
     */
    public static void loadApplicationPropery(String propFile, Properties properties)
            throws IOException, ConfigException {

        try (InputStream input = Files.newInputStream(Path.of(propFile))) {
            properties.load(input);
        } catch (IOException e) {
            logger.error("アプリケーションプロパティファイルが読み取れません。: {}", propFile, e);
            // throw new ConfigException("アプリケーションプロパティファイルが読み取れません。 : " + propFile, e);

            // プログラムを終了する
            logger.error("プログラムを終了させます。");
            System.exit(1);
        }

        // 必須プロパティが設定されていない場合は、プログラムを終了させる
        try {

            Optional.ofNullable(properties.getProperty("input.file.path"))
                    .orElseThrow(() -> new ConfigException("input.file.pathが未指定です。"));

            Optional.ofNullable(properties.getProperty("output.file.path"))
                    .orElseThrow(() -> new ConfigException("output.file.pathが未指定です。"));

            Optional.ofNullable(properties.getProperty("server.url"))
                    .orElseThrow(() -> new ConfigException("server.urlが未指定です。"));

        } catch (ConfigException e) {
            logger.error("アプリケーションプロパティの必須項目が未指定です。: {}", e.getMessage());
            // throw new ConfigException("アプリケーションプロパティの必須項目が未指定です。: " + e.getMessage(), e);

            // プログラムを終了する
            logger.error("プログラムを終了させます。");
            System.exit(1);
        }
    }
}
