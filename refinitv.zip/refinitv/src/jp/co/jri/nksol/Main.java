package jp.co.jri.nksol;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.jri.nksol.model.InputFileRecord;
import jp.co.jri.nksol.model.OutputFileRecord;
import jp.co.jri.nksol.model.Prop;
import jp.co.jri.nksol.util.BuildOutputFileRecord;
import jp.co.jri.nksol.util.LoadProperty;
import jp.co.jri.nksol.util.ReadInputFile;
import jp.co.jri.nksol.util.WriteOutputFile;

/**
 * アプリケーションの起動と、入力ファイルから出力ファイルを作成する処理を制御します。
 */
public class Main {
    private static final Logger logger = LoggerFactory.getLogger(Main.class);

    /**
     * 設定を読み込み、入力データを変換して出力ファイルに書き込みます。
     *
     * @param args コマンドライン引数
     * @throws Exception 設定の読み込み、入力処理、または出力処理でエラーが発生した場合
     */
    public static void main(String[] args) throws Exception {

        logger.info("Starting Program ........ processing");

        // [Step0] プロパティファイルの読み込み
        // ※プロパティが正常に取得できない場合、プログラムは終了する。
        Prop prop = new Prop();
        boolean status = LoadProperty.loadProperty(prop);
        if (status) {
            logger.info("各プロパティが正常に設定できたので、処理を進めます。");
        }

        // // [Step.1] 入力ファイルの読み込み
        // List<InputFileRecObject> listInputFile =
        // ReadInputFile.readInputFile(prop.getInputFilePath());

        // // [Step.2] 時価を取得し、出力データを組み立てる
        // List<OutputFileRecObject> listOutputFiles =
        // BuildOutputFileRecord.buildOutputFileObject(listInputFile);

        // // [Step.3] 出力ファイルの書き込み
        // WriteOutputFile.writeOutputFile(prop.getOutputFilePath(), listOutputFiles);

        // [Step.1] 入力ファイルの読み込み
        logger.info("[Step.1] 入力ファイルの読み込み");
        List<InputFileRecord> listInputFileRecord = ReadInputFile.readInputFileRecord(prop.getInputFilePath());

        // [Step.2] 時価を取得し、出力データを組み立てる
        logger.info("[Step.2] 時価を取得し、出力データを組み立てる");
        List<OutputFileRecord> listOutputFilesRecord = BuildOutputFileRecord.buildOutputFileRecord(listInputFileRecord);

        // [Step.3] 出力ファイルの書き込み
        logger.info("[Step.3] 出力ファイルの書き込み");
        WriteOutputFile.writeOutputFileRecord(prop.getOutputFilePath(), listOutputFilesRecord);

        // [Step.4] プログラム終了
        logger.info("[Step.4] プログラム正常終了");
        System.exit(0);
    }
}
