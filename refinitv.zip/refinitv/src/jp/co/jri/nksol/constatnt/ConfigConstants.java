package jp.co.jri.nksol.constatnt;

/**
 * 
 * ConfigConstants
 */
public final class ConfigConstants {

    private ConfigConstants() {
    }

    // 設定ファイル
    public static final String CONFIG_FILE = "application.properties";

    // 設定キー
    public static final String SERVER_HOST = "server.host";

    public static final String SERVER_PORT = "server.port";

    public static final String INPUT_DIR = "input.dir";

    public static final String OUTPUT_DIR = "output.dir";

    public static final String LOG_LEVEL = "log.level";

    // デフォルト値
    public static final String DEFAULT_HOST = "localhost";

    public static final int DEFAULT_PORT = 8080;

    public static final String DEFAULT_LOG_LEVEL = "INFO";
}
