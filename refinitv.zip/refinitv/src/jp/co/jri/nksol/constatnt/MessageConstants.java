package jp.co.jri.nksol.constatnt;

public final class MessageConstants {

    private MessageConstants() {
    }

    // INFO
    public static final String INFO_START = "処理を開始します。";

    public static final String INFO_END = "処理を正常終了しました。";

    // CONFIG
    public static final String CONFIG_NOT_FOUND = "設定ファイルが存在しません。";

    public static final String CONFIG_INVALID = "設定値が不正です。";

    // FILE
    public static final String FILE_NOT_FOUND = "入力ファイルが存在しません。";

    public static final String FILE_READ_ERROR = "ファイルの読み込みに失敗しました。";

    public static final String FILE_WRITE_ERROR = "ファイルの書き込みに失敗しました。";

    // BUSINESS
    public static final String STOCK_SHORTAGE = "在庫不足です。";

    public static final String INVALID_AGE = "18歳未満は利用できません。";

    public static final String DUPLICATE_DATA = "既に登録済みです。";

    // SYSTEM
    public static final String SYSTEM_ERROR = "システムエラーが発生しました。";
}