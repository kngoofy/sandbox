package jp.co.jri.nksol.constatnt;

public class StatusConstants {

    public static final String SUCCESS = "0";
    public static final String WARNING = "1";
    public static final String ERROR = "9";

    private StatusConstants() {
    }
}