package jp.co.jri.nksol.constatnt;

/**
 * 
 * FileConstants
 */
public final class FileConstants {

    private FileConstants() {
    }

    // ディレクトリ
    public static final String INPUT_DIR = "input";
    public static final String OUTPUT_DIR = "output";
    public static final String LOG_DIR = "log";
    public static final String CONFIG_DIR = "config";

    // ファイル名
    public static final String CONFIG_FILE = "application.properties";

    public static final String INPUT_FILE = "input.csv";

    public static final String OUTPUT_FILE = "output.csv";

    // 拡張子
    public static final String EXT_CSV = ".csv";
    public static final String EXT_TXT = ".txt";
    public static final String EXT_LOG = ".log";

    // 区切り文字
    public static final String CSV_DELIMITER = ",";

}