package jp.co.jri.nksol.constatnt;

/**
 * 
 * ErrorCode
 */
public enum ErrorCode {

    CONFIG_NOT_FOUND("CFG001"),
    CONFIG_INVALID("CFG002"),

    FILE_NOT_FOUND("FIL001"),
    FILE_READ_ERROR("FIL002"),
    FILE_WRITE_ERROR("FIL003"),

    STOCK_SHORTAGE("BUS001"),
    INVALID_AGE("BUS002"),

    DB_ERROR("SYS001"),
    NETWORK_ERROR("SYS002"),
    UNKNOWN_ERROR("SYS999");

    private final String code;

    ErrorCode(String code) {
        this.code = code;
    }

    public String getCode() {
        return code;
    }
}