package jp.co.jri.nksol.service;

public class GetJika {
    String dmy;
}
