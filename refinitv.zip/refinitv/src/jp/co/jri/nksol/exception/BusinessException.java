package jp.co.jri.nksol.exception;

/**
 * 業務処理で発生したエラーを表す例外です。
 * エラーコードと例外メッセージを保持します。
 */
public class BusinessException extends Exception {

    private final String errorCode;

    /**
     * エラーコードとメッセージを指定して業務例外を生成します。
     *
     * @param errorCode 業務エラーを識別するコード
     * @param message 利用者またはログに表示するエラーメッセージ
     */
    public BusinessException(
            String errorCode,
            String message) {

        super(message);
        this.errorCode = errorCode;
    }

    /**
     * エラーコード、メッセージ、発生原因を指定して業務例外を生成します。
     *
     * @param errorCode 業務エラーを識別するコード
     * @param message 利用者またはログに表示するエラーメッセージ
     * @param cause この例外の発生原因となった例外
     */
    public BusinessException(
            String errorCode,
            String message,
            Throwable cause) {

        super(message, cause);
        this.errorCode = errorCode;
    }

    /**
     * 業務エラーコードを取得します。
     *
     * @return 業務エラーコード
     */
    public String getErrorCode() {
        return errorCode;
    }
}