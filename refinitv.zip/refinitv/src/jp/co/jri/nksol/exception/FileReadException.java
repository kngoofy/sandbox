package jp.co.jri.nksol.exception;

/**
 * ファイルの読み込み中に発生したエラーを表す例外です。
 */
public class FileReadException extends Exception {

    /**
     * エラーメッセージを指定してファイル読み込み例外を生成します。
     *
     * @param message ファイル読み込み処理で発生したエラーの内容
     */
    public FileReadException(String message) {
        super(message);
    }

    /**
     * エラーメッセージと発生原因を指定してファイル読み込み例外を生成します。
     *
     * @param message ファイル読み込み処理で発生したエラーの内容
     * @param cause ファイル読み込み処理で発生した例外
     */
    public FileReadException(String message, Throwable cause) {
        super(message, cause);
    }
}