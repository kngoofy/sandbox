package jp.co.jri.nksol.exception;

/**
 * 設定ファイルの読み込みや設定値の処理で発生したエラーを表す例外です。
 */
public class ConfigException extends Exception {

    /**
     * エラーメッセージを指定して設定例外を生成します。
     *
     * @param message 設定処理で発生したエラーの内容
     */
    public ConfigException(String message) {
        super(message);
    }

    /**
     * 発生原因を指定して設定例外を生成します。
     *
     * @param cause 設定処理で発生した例外
     */
    public ConfigException(Throwable cause) {
        super(cause);
    }

    /**
     * エラーメッセージと発生原因を指定して設定例外を生成します。
     *
     * @param message 設定処理で発生したエラーの内容
     * @param cause 設定処理で発生した例外
     */
    public ConfigException(String message, Throwable cause) {
        super(message, cause);
    }

}