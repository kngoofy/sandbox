package jp.co.jri.nksol.exception;

/**
 * システム処理中に発生したエラーを表す実行時例外です。
 * エラーコードと例外メッセージを保持します。
 */
public class SystemException extends RuntimeException {

    private final String errorCode;

    /**
     * エラーコードとメッセージを指定してシステム例外を生成します。
     *
     * @param errorCode システムエラーを識別するコード
     * @param message エラーの内容を示すメッセージ
     */
    public SystemException(
            String errorCode,
            String message) {

        super(message);
        this.errorCode = errorCode;
    }

    /**
     * エラーコード、メッセージ、発生原因を指定してシステム例外を生成します。
     *
     * @param errorCode システムエラーを識別するコード
     * @param message エラーの内容を示すメッセージ
     * @param cause この例外の発生原因となった例外
     */
    public SystemException(
            String errorCode,
            String message,
            Throwable cause) {

        super(message, cause);
        this.errorCode = errorCode;
    }

    /**
     * システムエラーコードを取得します。
     *
     * @return システムエラーコード
     */
    public String getErrorCode() {
        return errorCode;
    }
}