package jp.co.jri.nksol.model;

/**
 * 入力ファイルの1レコード分の値を保持するオブジェクトです。
 */
public class InputFileRecObject {

    String ricCode;
    String col1;
    String col2;

    /**
     * 各項目の値を指定して入力レコードを生成します。
     *
     * @param ricCode RICコード
     * @param col1 1番目の項目の値
     * @param col2 2番目の項目の値
     */
    public InputFileRecObject(String ricCode, String col1, String col2) {
        this.ricCode = ricCode;
        this.col1 = col1;
        this.col2 = col2;
    }

    /**
     * RICコードを取得します。
     *
     * @return RICコード
     */
    public String getRicCode() {
        return ricCode;
    }

    /**
     * RICコードを設定します。
     *
     * @param ricCode 設定するRICコード
     */
    public void setRicCode(String ricCode) {
        this.ricCode = ricCode;
    }

    /**
     * 1番目の項目の値を取得します。
     *
     * @return 1番目の項目の値
     */
    public String getCol1() {
        return col1;
    }

    /**
     * 1番目の項目の値を設定します。
     *
     * @param col1 設定する値
     */
    public void setCol1(String col1) {
        this.col1 = col1;
    }

    /**
     * 2番目の項目の値を取得します。
     *
     * @return 2番目の項目の値
     */
    public String getCol2() {
        return col2;
    }

    /**
     * 2番目の項目の値を設定します。
     *
     * @param col2 設定する値
     */
    public void setCol2(String col2) {
        this.col2 = col2;
    }

    /**
     * このオブジェクトの項目を文字列で返します。
     *
     * @return 項目名と各値を含む文字列
     */
    @Override
    public String toString() {
        return "InputFileRecObject [ricCode=" + ricCode + ", col1=" + col1 + ", col2=" + col2 + "]";
    }
}
