package jp.co.jri.nksol.model;

/**
 * 入力ファイルの1レコード分の値を表します。
 *
 * @param ricCode RICコード
 * @param col1 1番目の項目の値
 * @param col2 2番目の項目の値
 * @throws IllegalArgumentException RICコードが {@code null} の場合
 */
public record InputFileRecord(

                String ricCode,
                String col1,
                String col2

) implements FileRecord {

        /** レコードで扱う最大階層数です。 */
        public static final int MAX_LEVEL = 10;

        /**
         * RICコードが指定されていることを確認して入力レコードを生成します。
         *
         * @param ricCode RICコード
         * @param col1 1番目の項目の値
         * @param col2 2番目の項目の値
         */
        public InputFileRecord {
                // RICコードは必須項目です。
                if (ricCode == null) {
                        throw new IllegalArgumentException();
                }

        }

        /**
         * このレコードの名前を取得します。
         *
         * @return レコード名
         */
        @Override
        public String name() {
                return "jika";
        }

}
