package jp.co.jri.nksol.model;

import java.nio.file.Path;

/**
 * app.propertiesで定義されたアプリケーション設定を保持するモデルクラス。
 */
public class Prop {

    /** アプリケーション名。 */
    String appName;
    /** アプリケーションのバージョン。 */
    String appVersion;
    /** 入力ファイルのパス。 */
    Path inputFilePath;
    /** 出力ファイルのパス。 */
    Path outputFilePath;
    /** サーバーのURL。 */
    String serverUrl;

    /** 保持している設定値を文字列形式で返す。 */
    @Override
    public String toString() {
        return "Prop{appName='" + appName + "', appVersion='" + appVersion + "', inputFilePath=" + inputFilePath
                + ", outputFilePath=" + outputFilePath + ", serverUrl='" + serverUrl + "'}";
    }

    /** @return アプリケーション名 */
    public String getAppName() {
        return appName;
    }

    /** @param appName アプリケーション名 */
    public void setAppName(String appName) {
        this.appName = appName;
    }

    /** @return アプリケーションのバージョン */
    public String getAppVersion() {
        return appVersion;
    }

    /** @param appVersion アプリケーションのバージョン */
    public void setAppVersion(String appVersion) {
        this.appVersion = appVersion;
    }

    /** @return 入力ファイルのパス */
    public Path getInputFilePath() {
        return inputFilePath;
    }

    /** @param inputFilePath 入力ファイルのパス */
    public void setInputFilePath(Path inputFilePath) {
        this.inputFilePath = inputFilePath;
    }

    /** @return 出力ファイルのパス */
    public Path getOutputFilePath() {
        return outputFilePath;
    }

    /** @param outputFilePath 出力ファイルのパス */
    public void setOutputFilePath(Path outputFilePath) {
        this.outputFilePath = outputFilePath;
    }

    /** @return サーバーのURL */
    public String getServerUrl() {
        return serverUrl;
    }

    /** @param serverUrl サーバーのURL */
    public void setServerUrl(String serverUrl) {
        this.serverUrl = serverUrl;
    }
}
