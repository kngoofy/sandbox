package jp.co.jri.nksol.model;

/**
 * 出力ファイルの1レコード分の値を表します。
 *
 * @param ricCode RICコード
 * @param col1 1番目の項目の値
 * @param col2 2番目の項目の値
 */
public record OutputFileRecord(

        String ricCode,
        String col1,
        String col2

) implements FileRecord {
    /**
     * RICコードが指定されていることを確認して出力レコードを生成します。
     *
     * @param ricCode RICコード
     * @param col1 1番目の項目の値
     * @param col2 2番目の項目の値
     * @throws IllegalArgumentException RICコードが {@code null} の場合
     */
    public OutputFileRecord {

        // RICコードは必須項目です。
        if (ricCode == null) {
            throw new IllegalArgumentException();
        }

    }

    /**
     * このレコードの名前を取得します。
     *
     * @return レコード名
     */
    @Override
    public String name() {
        return "jika";
    }

}
