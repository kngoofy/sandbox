package jp.co.jri.nksol.model;

/**
 * ファイルに記録するレコードが共通して持つ情報を定義します。
 */
public interface FileRecord {
    /**
     * レコードの名前を取得します。
     *
     * @return レコードの名前
     */
    String name();
}
